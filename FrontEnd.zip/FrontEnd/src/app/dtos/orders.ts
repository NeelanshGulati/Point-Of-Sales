export class Order {
    public oId: number;
  	public date: string;
    public totalPrice: number;
    public customerId: number;
  }