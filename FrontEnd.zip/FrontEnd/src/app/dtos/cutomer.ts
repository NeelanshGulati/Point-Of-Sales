export class Customer {
    public employeeCode: number;
	public employeeName: string;
	public location: string;
	public email: string;
	public dateOfBirth: string
  }